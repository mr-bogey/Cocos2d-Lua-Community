luaoc = require(cc.PACKAGE_NAME .. ".platform.luaoc")
