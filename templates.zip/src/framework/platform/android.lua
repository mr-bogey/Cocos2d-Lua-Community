luaj = require(cc.PACKAGE_NAME .. ".platform.luaj")
